export default function Github() { return <h1>Github Page</h1>; }
export async function githubInfoLoader() {
    return null; // Mock loader
}